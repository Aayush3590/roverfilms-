import { motion } from "framer-motion";
import portfolio1 from "@/assets/portfolio-1.jpg";
import portfolio2 from "@/assets/portfolio-2.jpg";
import portfolio3 from "@/assets/portfolio-3.jpg";
import portfolio4 from "@/assets/portfolio-4.jpg";
import portfolio5 from "@/assets/portfolio-5.jpg";
import portfolio6 from "@/assets/portfolio-6.jpg";

const projects = [
  { src: portfolio1, title: "Mountain Roads", category: "Landscape" },
  { src: portfolio2, title: "Golden Vows", category: "Wedding" },
  { src: portfolio3, title: "Neon Nights", category: "Urban" },
  { src: portfolio4, title: "Soul Portrait", category: "Documentary" },
  { src: portfolio5, title: "Ocean's Edge", category: "Nature" },
  { src: portfolio6, title: "Behind the Lens", category: "BTS" },
];

const PortfolioSection = () => {
  return (
    <section id="work" className="py-32 px-6">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="font-body text-xs uppercase tracking-[0.4em] text-primary mb-4">Portfolio</p>
          <h2 className="font-display text-4xl md:text-6xl font-bold text-foreground">
            Selected <span className="italic text-gradient-gold">Work</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group relative overflow-hidden cursor-pointer aspect-[4/5]"
            >
              <img
                src={project.src}
                alt={project.title}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6">
                <p className="font-body text-xs uppercase tracking-[0.3em] text-primary mb-1">
                  {project.category}
                </p>
                <h3 className="font-display text-2xl font-semibold text-foreground">
                  {project.title}
                </h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;
