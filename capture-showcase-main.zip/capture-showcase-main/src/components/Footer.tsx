import { Instagram, Youtube, Video } from "lucide-react";

const Footer = () => {
  return (
    <footer className="border-t border-border py-12 px-6">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <a href="#" className="font-display text-xl font-bold text-foreground">
          LENS<span className="text-gradient-gold">CRAFT</span>
        </a>

        <div className="flex items-center gap-6">
          {[Instagram, Youtube, Video].map((Icon, i) => (
            <a
              key={i}
              href="#"
              className="text-muted-foreground hover:text-primary transition-colors duration-300"
            >
              <Icon size={18} strokeWidth={1.5} />
            </a>
          ))}
        </div>

        <p className="font-body text-xs text-muted-foreground">
          © 2026 LensCraft. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
