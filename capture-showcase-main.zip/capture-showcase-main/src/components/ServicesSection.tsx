import { motion } from "framer-motion";
import { Film, Camera, Clapperboard, Aperture } from "lucide-react";

const services = [
  {
    icon: Film,
    title: "Wedding Films",
    description: "Cinematic wedding films that capture the emotion, joy, and intimate moments of your special day.",
  },
  {
    icon: Camera,
    title: "Commercial",
    description: "High-end brand content and commercial videography that elevates your visual identity.",
  },
  {
    icon: Clapperboard,
    title: "Music Videos",
    description: "Creative direction and cinematography for music videos that captivate and inspire.",
  },
  {
    icon: Aperture,
    title: "Documentary",
    description: "Compelling documentary filmmaking that uncovers truth and tells powerful human stories.",
  },
];

const ServicesSection = () => {
  return (
    <section id="services" className="py-32 px-6 bg-secondary/50">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="font-body text-xs uppercase tracking-[0.4em] text-primary mb-4">What I Do</p>
          <h2 className="font-display text-4xl md:text-6xl font-bold text-foreground">
            My <span className="italic text-gradient-gold">Services</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group bg-card border border-border p-8 hover:border-primary/40 transition-all duration-500 hover:shadow-gold"
            >
              <service.icon className="w-8 h-8 text-primary mb-6" strokeWidth={1} />
              <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                {service.title}
              </h3>
              <p className="font-body text-sm text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
